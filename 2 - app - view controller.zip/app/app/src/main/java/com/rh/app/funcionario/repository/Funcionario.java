package com.rh.app.funcionario.repository;

public interface Funcionario {

}
